package tdc.edu.vn.test.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import tdc.edu.vn.test.DBHelper.DBHelperVC;
import tdc.edu.vn.test.Model.VanChuyen;


public class DBVC {
    DBHelperVC dbHelperVC;
    SQLiteDatabase database;
    public Cursor layTatCaDuLieu() {
        // Biến cot là khai báo danh sách các cột cần lấy.
        String[] cot = {DBHelperVC.COT_ID,
                DBHelperVC.COT_NGAYVC,
                DBHelperVC.COT_SOLUONG,
                DBHelperVC.COT_GIOITINH,
                DBHelperVC.COT_TENVATU,
                DBHelperVC.COT_TENCONGTRINH,
        };
        Cursor cursor = null;
        cursor = database.query(DBHelperVC.
                        TEN_BANG_VANCHUYEN, cot, null, null, null, null,
                DBHelperVC.COT_ID + " DESC");
        return cursor;
    }
    public DBVC(Context context) {
        dbHelperVC = new DBHelperVC(context);
    }

    public long them(VanChuyen vanChuyen) {
        ContentValues values = new ContentValues();
        values.put(DBHelperVC.COT_NGAYVC,
                vanChuyen.getNgayVC());
        values.put(DBHelperVC.COT_SOLUONG,
                vanChuyen.getSoLuong());
        values.put(DBHelperVC.COT_GIOITINH,
                vanChuyen.getGioiTinh());

        return database.insert(DBHelperVC.
                TEN_BANG_VANCHUYEN, null, values);
    }

    public long sua(VanChuyen vanChuyen) {
        ContentValues values = new ContentValues();
        values.put(DBHelperVC.COT_NGAYVC,
                vanChuyen.getNgayVC());
        values.put(DBHelperVC.COT_SOLUONG,
                vanChuyen.getSoLuong());
        values.put(DBHelperVC.COT_GIOITINH,
                vanChuyen.getGioiTinh());
        return database.update(DBHelperVC
                        .TEN_BANG_VANCHUYEN, values,
                DBHelperVC.COT_ID + " = "
                        + vanChuyen.getId(), null);
    }


    public long xoa(VanChuyen vanChuyen) {
        return database.delete(DBHelperVC
                .TEN_BANG_VANCHUYEN, DBHelperVC
                .COT_NGAYVC + " = " + "'" +
                vanChuyen.getNgayVC() + "'", null);
    }

   public ArrayList<VanChuyen> LayDL()
    {
        ArrayList<VanChuyen> data = new ArrayList<>();
        String sql="select * from VanChuyen";
        SQLiteDatabase db= dbHelperVC.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);

        try {
            cursor.moveToFirst();
            do {
                VanChuyen vanChuyen = new VanChuyen();
                vanChuyen.setNgayVC(cursor.getString(0));
                vanChuyen.setSoLuong(cursor.getString(1));

                data.add(vanChuyen);
            }
            while (cursor.moveToNext());
        }
        catch (Exception ex)
        {

        }


        return  data;
    }


   
}
