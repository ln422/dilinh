package tdc.edu.vn.test.CustomAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import tdc.edu.vn.test.Model.Cong_Trinh;

import tdc.edu.vn.test.R;

public class CustomAdapter_Cong_Trinh extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<Cong_Trinh> data;

    public CustomAdapter_Cong_Trinh(Context context, int resource, ArrayList<Cong_Trinh> data) {
        super(context, resource);
        this.context=context;
        this.resource= resource;
        this.data= data;
    }
    @Override
    public int getCount() {
        return data.size();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(resource,null);

        TextView txtmact= view.findViewById(R.id.txtmact);
        TextView txttenct= view.findViewById(R.id.txttenct);
        TextView txtdiachi= view.findViewById(R.id.txtdiachi);
        ListView danhsach= view.findViewById(R.id.lvDanhSachct);
        Cong_Trinh cong_trinh = data.get(position);
        return  view;
    }
}
