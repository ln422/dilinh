package tdc.edu.vn.test.Model;

public class Cong_Trinh {
    String MaCT,TenCT;

    String DiaChi;
int id;

    public String getMaCT() {
        return MaCT;
    }

    public void setMaCT(String maCT) {
        MaCT = maCT;
    }

    public String getTenCT() {
        return TenCT;
    }

    public void setTenCT(String tenCT) {
        TenCT = tenCT;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String diaChi) {
        DiaChi = diaChi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }




    @Override
    public String toString() {
        return "Cong_Trinh{" +
                "MaCT='" + MaCT + '\'' +
                ", TenCT='" + TenCT + '\'' +
                ", DiaChi='" + DiaChi + '\'' +
                ", id=" + id +
                '}';
    }


}
