package tdc.edu.vn.test.GiaoDien;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import java.util.ArrayList;
import tdc.edu.vn.test.CustomAdapter.CustomAdapter_Cong_Trinh;
import tdc.edu.vn.test.CustomAdapter.CustomAdapter_VC;
import tdc.edu.vn.test.Model.Cong_Trinh;
import tdc.edu.vn.test.R;

public class MainActivity_congtrinh extends AppCompatActivity {
    EditText Mact,TenCT,DiaChi;
    Button btnThem, btnXoa, btnSua, btnClear;
    ListView lvDanhSach;
    ArrayList<Cong_Trinh> data_CongTrinh = new ArrayList<Cong_Trinh>();
    ArrayAdapter adapter_CongTrinh;
    CustomAdapter_Cong_Trinh adapter_CT;
    int index=-1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_congtrinh);
        setControl();
        setEvent();
    }


    private void setEvent() {
        adapter_CT= new CustomAdapter_Cong_Trinh(this,R.layout.list_item_ct, data_CongTrinh );
        lvDanhSach.setAdapter(adapter_CT);

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cong_Trinh cong_trinh = new Cong_Trinh();
                cong_trinh.setMaCT(Mact.getText().toString());
                cong_trinh.setTenCT(TenCT.getText().toString());
                cong_trinh.setDiaChi(DiaChi.getText().toString());

                data_CongTrinh.add(cong_trinh);
                adapter_CT.notifyDataSetChanged();
            }
        });
        lvDanhSach.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cong_Trinh cong_trinh = data_CongTrinh.get(position);
                Mact.setText(cong_trinh.getMaCT());
                TenCT.setText(cong_trinh.getTenCT());
                index= position;
            }
        });
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_CongTrinh.remove(index);
                adapter_CT.notifyDataSetChanged();
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cong_Trinh cong_trinh = data_CongTrinh.get(index);
                cong_trinh.setMaCT(Mact.getText().toString());
                cong_trinh.setTenCT(TenCT.getText().toString());
                cong_trinh.setDiaChi(DiaChi.getText().toString());
                adapter_CT.notifyDataSetChanged();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mact.setText("");
                TenCT.setText("");
                DiaChi.setText("");
            }
        });

    }

    private void setControl() {
        Mact=findViewById(R.id.txtmact);
        TenCT=findViewById(R.id.txttenct);
        DiaChi=findViewById(R.id.txtdiachi);
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnXoa = findViewById(R.id.btnXoa);
        btnClear = findViewById(R.id.btnClear);
        lvDanhSach = findViewById(R.id.lvDanhSachct);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_congtrinh, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mnThoat:
                Log.d("test", "Thoat");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity_congtrinh.this);
                builder.setTitle("Thông Báo");
                builder.setMessage("Bạn Có Muốn Thoát");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

}