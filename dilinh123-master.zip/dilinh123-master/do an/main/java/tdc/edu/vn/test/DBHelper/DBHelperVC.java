package tdc.edu.vn.test.DBHelper;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperVC extends SQLiteOpenHelper {

    // Tên cơ sở dữ liệu
    public static final String TEN_DATABASE = "QuanLyVanChuyen";
    // Tên bảng
    public static final String TEN_BANG_VANCHUYEN = "VanChuyen";
    // Bảng gồm 3 cột _id, _ten và _ma.
    public static final String COT_ID = "_id";
    public static final String COT_NGAYVC = "_ngayvc";
    public static final String COT_SOLUONG = "_soluong";
    public static final String COT_GIOITINH = "_gioitinh";
    public static final String COT_TENVATU = "_tenvattu";
    public static final String COT_TENCONGTRINH = "_tencongtrinh";


    private static final String TAO_BANG_VANCHUYEN = ""
            + "create table " + TEN_BANG_VANCHUYEN + " ( "
            + COT_ID + " integer primary key autoincrement ,"
            + COT_NGAYVC + " text not null, "
            + COT_SOLUONG + " text not null "
            + COT_GIOITINH + " text not null "
            + COT_TENVATU + " text not null) "
            + COT_TENCONGTRINH + " text not null, ";




    public DBHelperVC(Context context) {
        super(context,TEN_DATABASE,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    /*   @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(TAO_BANG_CONGTRINH);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql="create table CongTrinh(mact text ,tenct text)";
            db.execSQL(sql);
        }
    */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
