package tdc.edu.vn.test.GiaoDien;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import tdc.edu.vn.test.R;

public class MainActivity_maintc extends AppCompatActivity {
    private  static  int SPLASH_SCREEN = 4000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_maintc);
        ImageView cat = (ImageView) findViewById(R.id.imgCat);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity_maintc.this,MainActivity_chucnang.class);
                startActivity(intent);
                finish();
            }
        }, SPLASH_SCREEN);
        final AnimationDrawable runningCat = (AnimationDrawable) cat.getDrawable();
        runningCat.start();
    }

}

