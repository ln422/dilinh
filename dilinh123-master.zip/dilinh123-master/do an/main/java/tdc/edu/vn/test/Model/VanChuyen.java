package tdc.edu.vn.test.Model;

public class VanChuyen {
    String NgayVC, SoLuong;
    Boolean GioiTinh;
    String VatTu, CongTrinh;
int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNgayVC() {
        return NgayVC;
    }

    public String getSoLuong() {
        return SoLuong;
    }

    public Boolean getGioiTinh() {
        return GioiTinh;
    }

    public String getVatTu() {
        return VatTu;
    }

    public String getCongTrinh() {
        return CongTrinh;
    }

    public void setNgayVC(String ngayVC) {
        NgayVC = ngayVC;
    }

    public void setSoLuong(String soLuong) {
        SoLuong = soLuong;
    }

    public void setGioiTinh(Boolean gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public void setVatTu(String vatTu) {
        VatTu = vatTu;
    }

    public void setCongTrinh(String congTrinh) {
        CongTrinh = congTrinh;
    }

    @Override
    public String toString() {
        return "VanChuyen{" +
                "NgayVC='" + NgayVC + '\'' +
                ", SoLuong='" + SoLuong + '\'' +
                ", GioiTinh=" + GioiTinh +
                ", VatTu='" + VatTu + '\'' +
                ", CongTrinh='" + CongTrinh + '\'' +
                ", id=" + id +
                '}';
    }


}
