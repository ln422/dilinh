package tdc.edu.vn.test.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import tdc.edu.vn.test.DBHelper.DBHelper_VT;
import tdc.edu.vn.test.Model.VatTu;


public class DB_VT {
    DBHelper_VT dbHelper_vt;
    SQLiteDatabase database;
    public Cursor layTatCaDuLieu() {
        // Biến cot là khai báo danh sách các cột cần lấy.
        String[] cot = {DBHelper_VT.COT_ID,
                DBHelper_VT.MAVT,
                DBHelper_VT.TENVT,
                DBHelper_VT.GIA,
                DBHelper_VT.DVT,

        };
        Cursor cursor = null;
        cursor = database.query(DBHelper_VT.
                        TEN_BANG_VAT_TU, cot, null, null, null, null,
                DBHelper_VT.COT_ID + " DESC");
        return cursor;
    }
    public DB_VT(Context context) {
        dbHelper_vt = new DBHelper_VT(context);
    }

    public long them(VatTu vatTu) {
        ContentValues values = new ContentValues();
        values.put(DBHelper_VT.MAVT,
                vatTu.getMaVT());
        values.put(DBHelper_VT.TENVT,
                vatTu.getTenVT());
        values.put(DBHelper_VT.GIA,
                vatTu.getGiaVC());
        values.put(DBHelper_VT.DVT,
                vatTu.getDonVT());

        return database.insert(DBHelper_VT.
                TEN_BANG_VAT_TU, null, values);
    }

    public long sua(VatTu vatTu) {
        ContentValues values = new ContentValues();
        values.put(DBHelper_VT.MAVT,
                vatTu.getMaVT());
        values.put(DBHelper_VT.TENVT,
                vatTu.getTenVT());
        values.put(DBHelper_VT.GIA,
                vatTu.getGiaVC());
        values.put(DBHelper_VT.DVT,
                vatTu.getDonVT());
        return database.update(DBHelper_VT
                        .TEN_BANG_VAT_TU, values,
                DBHelper_VT.COT_ID + " = "
                        + vatTu.getI(), null);
    }


    public long xoa(VatTu vatTu) {
        return database.delete(DBHelper_VT
                .TEN_BANG_VAT_TU, DBHelper_VT
                .MAVT + " = " + "'" +
                vatTu.getMaVT() + "'", null);
    }

   public ArrayList<VatTu> LayDL()
    {
        ArrayList<VatTu> data = new ArrayList<>();
        String sql="select * from VatTu";
        SQLiteDatabase db= dbHelper_vt.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);

        try {
            cursor.moveToFirst();
            do {
                VatTu vatTu = new VatTu();
                vatTu.setMaVT(cursor.getString(0));
                vatTu.setTenVT(cursor.getString(1));

                data.add(vatTu);
            }
            while (cursor.moveToNext());
        }
        catch (Exception ex)
        {

        }


        return  data;
    }


   
}
