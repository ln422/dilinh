package tdc.edu.vn.test.CustomAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import tdc.edu.vn.test.Model.VatTu;

import tdc.edu.vn.test.R;

public class CustomAdapter_VatTu extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<VatTu> data;

    public CustomAdapter_VatTu(Context context, int resource, ArrayList<VatTu> data) {
        super(context, resource);
        this.context=context;
        this.resource= resource;
        this.data= data;
    }
    @Override
    public int getCount() {
        return data.size();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(resource,null);

        TextView txtmavt= view.findViewById(R.id.mavt);
        TextView txttenvt= view.findViewById(R.id.tenvt);
        TextView txtgiavc= view.findViewById(R.id.giavanchuyen);
        TextView txtdonvitinh= view.findViewById(R.id.donvitinh);
        ListView danhsach= view.findViewById(R.id.lvDanhSachct);
        VatTu vatTu = data.get(position);

//        txtmavt.setText(vatTu.getMaVT());
//        txttenvt.setText(vatTu.getTenVT());
//        txtdonvitinh.setText(vatTu.getDonVT());
//        txtgiavc.setText(vatTu.getGiaVC());


        return  view;
    }
}
