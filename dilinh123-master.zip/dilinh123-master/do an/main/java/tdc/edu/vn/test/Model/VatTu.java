package tdc.edu.vn.test.Model;

public class VatTu {

    String MaVT,TenVT,
             GiaVC,DonVT;
int i;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public String getMaVT() {
        return MaVT;
    }



    public void setMaVT(String maVT) {
        MaVT = maVT;
    }

    public String getTenVT() {
        return TenVT;
    }

    public void setTenVT(String tenVT) {
        TenVT = tenVT;
    }

    public String getGiaVC() {
        return GiaVC;
    }

    public void setGiaVC(String giaVC) {
        GiaVC = giaVC;
    }

    public String getDonVT() {
        return DonVT;
    }

    public void setDonVT(String donVT) {
        DonVT = donVT;
    }

    @Override
    public String toString() {
        return "VatTu{" +
                "MaVT='" + MaVT + '\'' +
                ", TenVT='" + TenVT + '\'' +
                ", GiaVC=" + GiaVC +
                ", DonVT=" + DonVT +
                ", i=" + i +
                '}';
    }
}
