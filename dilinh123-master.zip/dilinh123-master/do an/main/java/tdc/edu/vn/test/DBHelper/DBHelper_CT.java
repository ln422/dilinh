package tdc.edu.vn.test.DBHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper_CT extends SQLiteOpenHelper {

    // Tên cơ sở dữ liệu
    public static final String TEN_DATABASE = "QuanLyVanChuyen";
    // Tên bảng
    public static final String TEN_BANG_CONGTRINH = "CongTrinh";
    // Bảng gồm 3 cột _id, _ten và _ma.
    public static final String COT_ID = "_id";
    public static final String MACT = "_mact";
    public static final String TENCT = "_tenct";
    public static final String DIACHI = "_diachi";
   


    private static final String TAO_BANG_VANCHUYEN = ""
            + "create table " + TEN_BANG_CONGTRINH + " ( "
            + COT_ID + " integer primary key autoincrement ,"
            + MACT + " text not null, "
            + TENCT + " text not null "
            + DIACHI + " text not null ";
          




    public DBHelper_CT(Context context) {
        super(context,TEN_DATABASE,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    /*   @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(TAO_BANG_CONGTRINH);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql="create table CongTrinh(mact text ,tenct text)";
            db.execSQL(sql);
        }
    */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
