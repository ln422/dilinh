package tdc.edu.vn.test.DBHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper_VT extends SQLiteOpenHelper {

    // Tên cơ sở dữ liệu
    public static final String TEN_DATABASE = "QuanLyVanChuyen";
    // Tên bảng
    public static final String VAT_TU = "VatTu";
    // Bảng gồm 3 cột _id, _ten và _ma.
    public static final String COT_ID = "_id";
    public static final String MAVT = "_mavt";
    public static final String TENVT = "_tenvt";
    public static final String GIA = "_gia";
    public static final String DVT = "_dvt";
    public static final String TEN_BANG_VAT_TU = VAT_TU;


    private static final String TAO_BANG_VANCHUYEN = ""
            + "create table " + VAT_TU + " ( "
            + COT_ID + " integer primary key autoincrement ,"
            + MAVT + " text not null, "
            + TENVT + " text not null "
            + GIA + " text not null "
            + DVT + " text not null ";





    public DBHelper_VT(Context context) {
        super(context,TEN_DATABASE,null,1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    /*   @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(TAO_BANG_CONGTRINH);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql="create table CongTrinh(mact text ,tenct text)";
            db.execSQL(sql);
        }
    */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
