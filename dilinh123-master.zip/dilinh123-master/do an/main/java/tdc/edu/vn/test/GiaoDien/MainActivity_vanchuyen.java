package tdc.edu.vn.test.GiaoDien;
import android.content.DialogInterface;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;


import java.util.ArrayList;

import tdc.edu.vn.test.CustomAdapter.CustomAdapter_VC;
import tdc.edu.vn.test.R;
import tdc.edu.vn.test.Model.VanChuyen;

public class MainActivity_vanchuyen extends AppCompatActivity implements SensorEventListener {
    EditText editNgay, editSL;
    RadioButton radNam, radNu;
    Spinner spVattu, spCongTrinh;
    Button btnThem, btnXoa, btnSua, btnClear;
    ListView lvDanhSach;
    ArrayList<String> data_VatTu = new ArrayList<>();
    ArrayList<String> data_CongTrinh = new ArrayList<>();
    ArrayList<VanChuyen> data_VC = new ArrayList<>();
    ArrayAdapter adapter_VatTu;
    ArrayAdapter adapter_CongTrinh;
    CustomAdapter_VC adapter_VC;
    int index=-1;
    SensorManager sensorManager;
    long tgianTruoc;
    int i = 1;
    ImageView imgHinh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vanchuyen);
        setControl();
        setEvent();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_vanchuyen, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mnThoat:
                Log.d("test", "Thoat");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity_vanchuyen.this);
                builder.setTitle("Thông Báo");
                builder.setMessage("Bạn Có Muốn Thoát");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;

        }

        return super.onOptionsItemSelected(item);
    }




    private void setEvent() {
        KhoiTao();
        adapter_VatTu = new ArrayAdapter(this, android.R.layout.simple_spinner_item, data_VatTu);
        spVattu.setAdapter(adapter_VatTu);
        adapter_CongTrinh = new ArrayAdapter(this, android.R.layout.simple_spinner_item, data_CongTrinh);

        spCongTrinh.setAdapter(adapter_CongTrinh);

        adapter_VC= new CustomAdapter_VC(this, R.layout.list_item_vc, data_VC );
        lvDanhSach.setAdapter(adapter_VC);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorManager.registerListener((SensorEventListener) this,sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),SensorManager.SENSOR_DELAY_NORMAL);
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VanChuyen vanchuyen = new VanChuyen();
                vanchuyen.setNgayVC(editNgay.getText().toString());
                vanchuyen.setSoLuong(editSL.getText().toString());
                vanchuyen.setGioiTinh(radNam.isChecked());
                vanchuyen.setVatTu(spVattu.getSelectedItem().toString());
                vanchuyen.setCongTrinh(spCongTrinh.getSelectedItem().toString());
                data_VC.add(vanchuyen);
                adapter_VC.notifyDataSetChanged();
            }
        });

        lvDanhSach.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                VanChuyen vanchuyen = data_VC.get(position);
                editNgay.setText(vanchuyen.getNgayVC());
                editSL.setText(vanchuyen.getSoLuong());

                if(vanchuyen.getGioiTinh())
                    radNam.setChecked(true);
                else
                    radNu.setChecked(false);


                spVattu.setSelection(data_VatTu.indexOf(vanchuyen.getVatTu()));
                index= position;

            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_VC.remove(index);
                adapter_VC.notifyDataSetChanged();
            }
        });

        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                VanChuyen vanChuyen = data_VC.get(index);
                vanChuyen.setNgayVC(editNgay.getText().toString());
                vanChuyen.setSoLuong(editSL.getText().toString());
                vanChuyen.setGioiTinh(radNam.isChecked());
                vanChuyen.setVatTu(spVattu.getSelectedItem().toString());
                vanChuyen.setCongTrinh(spCongTrinh.getSelectedItem().toString());
                adapter_VC.notifyDataSetChanged();

            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editNgay.setText("");
                editSL.setText("");
                radNam.setChecked(true);
                spVattu.setSelection(0);
                spCongTrinh.setSelection(0);

            }
        });

    }
    private  void KhoiTao(){
        data_VatTu.add("Vat Tu Cong Ty Be Tong Ngoai Thuong");
        data_VatTu.add("Vat Tu Cong Ty An Nam");
        data_VatTu.add("Vat Tu Cong Ty Phu An Dong");
        data_CongTrinh.add("Truong THPT Thu Duc");
        data_CongTrinh.add("Ben Xe Mien Dong Moi");
        data_CongTrinh.add("Cau Vuot Suoi Tien");

        VanChuyen vanchuyen = new VanChuyen();
        vanchuyen.setNgayVC("25/09/2000");
        vanchuyen.setSoLuong("5000000");
        vanchuyen.setGioiTinh(true);
        vanchuyen.setVatTu("Vat Tu Cong Ty Be Tong Ngoai Thuong");
        vanchuyen.setCongTrinh("Ben Xe Mien Dong Moi");
    }

        private void setControl() {
            editNgay = findViewById(R.id.editNgay);
            editSL = findViewById(R.id.editSL);
            radNam = findViewById(R.id.radNam);
            radNu = findViewById(R.id.radNu);
            spVattu = findViewById(R.id.spVattu);
            spCongTrinh = findViewById(R.id.spCongTrinh);
            btnThem = findViewById(R.id.btnThem);
            btnSua = findViewById(R.id.btnSua);
            btnXoa = findViewById(R.id.btnXoa);
            btnClear = findViewById(R.id.btnClear);
            lvDanhSach = findViewById(R.id.lvDanhSachct);
            imgHinh = (ImageView) findViewById(R.id.imgHinh);


    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            // doi hinh
            layVecTorvathaydoitext(event);
        }
    }
    @Override

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    public void layVecTorvathaydoitext(SensorEvent event){
        float[] values = event.values;
        float x = values[0];
        float y = values[1];
        float z = values[2];
        float vector = ( x*x + y*y + z*z )/(SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH);
        if (vector >= 2){
            long tgSau = event.timestamp;
            if((tgSau - tgianTruoc) > 100){
                i++;

                if(i == 3 ){
                    imgHinh.setImageResource(R.drawable.kho);

                }
                if(i == 4 ){
                    imgHinh.setImageResource(R.drawable.chuyen);

                }
                if(i == 5 ){
                    imgHinh.setImageResource(R.drawable.giao);
                    i = 1;

                }

            }
            tgianTruoc = tgSau;
        }
    }

}

