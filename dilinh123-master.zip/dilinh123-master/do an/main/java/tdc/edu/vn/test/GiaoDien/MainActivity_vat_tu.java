package tdc.edu.vn.test.GiaoDien;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import tdc.edu.vn.test.CustomAdapter.CustomAdapter_VatTu;
import tdc.edu.vn.test.Model.VatTu;
import tdc.edu.vn.test.R;

public class MainActivity_vat_tu extends AppCompatActivity {
    EditText maVT,tenVT,donVT, giaVC;
    Button btnThem, btnXoa, btnSua, btnClear;
    ListView lvDanhSach;
    ArrayList<VatTu> data_vat_tu = new ArrayList<VatTu>();
    ArrayAdapter adapter_VatTu;
    CustomAdapter_VatTu adapter_VT;
    int index=-1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_vat_tu);
        setControl();
        setEvent();
    }
    private void setEvent() {
        KhoiTao();
        adapter_VT = new CustomAdapter_VatTu(this,R.layout.list_item_vt, data_vat_tu );
        lvDanhSach.setAdapter(adapter_VT);

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VatTu vat_tu = new VatTu();
                vat_tu.setMaVT(maVT.getText().toString());
                vat_tu.setTenVT(tenVT.getText().toString());
                vat_tu.setDonVT(donVT.getText().toString());
                vat_tu.setGiaVC(giaVC.getText().toString());
                data_vat_tu.add(vat_tu);
                adapter_VT.notifyDataSetChanged();
            }
        });
        lvDanhSach.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                VatTu vatTu = data_vat_tu.get(position);
                maVT.setText(vatTu.getMaVT());
                tenVT.setText(vatTu.getMaVT());
                donVT.setText(vatTu.getDonVT());
                giaVC.setText(vatTu.getGiaVC());
                index= position;
            }
        });
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_vat_tu.remove(index);
                adapter_VT.notifyDataSetChanged();
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VatTu vatTu = data_vat_tu.get(index);
                vatTu.setMaVT(maVT.getText().toString());
                vatTu.setTenVT(tenVT.getText().toString());
                vatTu.setDonVT(donVT.getText().toString());
                vatTu.setGiaVC(giaVC.getText().toString());
                adapter_VT.notifyDataSetChanged();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                maVT.setText("");
                tenVT.setText("");
                donVT.setText("");
                giaVC.setText("");
            }
        });

    }
    private  void KhoiTao(){
        VatTu VT = new VatTu();
        VT.setMaVT("123");
        VT.setTenVT("Da");
        VT.setDonVT("Kg");
        VT.setGiaVC("30000");
    }
    private void setControl() {
        maVT=findViewById(R.id.mavt);
        tenVT=findViewById(R.id.tenvt);
        giaVC=findViewById(R.id.giavanchuyen);
        donVT=findViewById(R.id.donvitinh);
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnXoa = findViewById(R.id.btnXoa);
        btnClear = findViewById(R.id.btnClear);
        lvDanhSach = findViewById(R.id.lvDanhSachct);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_vattu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.mnThoat:
                Log.d("test", "Thoat");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity_vat_tu.this);
                builder.setTitle("Thông Báo");
                builder.setMessage("Bạn Có Muốn Thoát");
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;

        }

        return super.onOptionsItemSelected(item);
    }
}
