package tdc.edu.vn.test.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import tdc.edu.vn.test.DBHelper.DBHelperVC;
import tdc.edu.vn.test.DBHelper.DBHelper_CT;
import tdc.edu.vn.test.Model.Cong_Trinh;
import tdc.edu.vn.test.Model.VanChuyen;


public class DB_CT {
    DBHelper_CT dbHelper_CT;
    SQLiteDatabase database;
    public Cursor layTatCaDuLieu() {
        // Biến cot là khai báo danh sách các cột cần lấy.
        String[] cot = {DBHelper_CT.COT_ID,
                DBHelper_CT.MACT,
                DBHelper_CT.TENCT,
                DBHelper_CT.DIACHI,

        };
        Cursor cursor = null;
        cursor = database.query(DBHelper_CT.
                        TEN_BANG_CONGTRINH, cot, null, null, null, null,
                DBHelper_CT.COT_ID + " DESC");
        return cursor;
    }
    public DB_CT(Context context) {
        dbHelper_CT = new DBHelper_CT(context);
    }

    public long them(Cong_Trinh cong_trinh) {
        ContentValues values = new ContentValues();
        values.put(DBHelper_CT.MACT,
                cong_trinh.getMaCT());
        values.put(DBHelper_CT.TENCT,
                cong_trinh.getTenCT());
        values.put(DBHelper_CT.DIACHI,
                cong_trinh.getDiaChi());

        return database.insert(DBHelper_CT.
                TEN_BANG_CONGTRINH, null, values);
    }

    public long sua(Cong_Trinh cong_trinh) {
        ContentValues values = new ContentValues();
        values.put(DBHelper_CT.MACT,
                cong_trinh.getMaCT());
        values.put(DBHelper_CT.TENCT,
                cong_trinh.getTenCT());
        values.put(DBHelper_CT.DIACHI,
                cong_trinh.getDiaChi());
        return database.update(DBHelper_CT
                        .TEN_BANG_CONGTRINH, values,
                DBHelper_CT.COT_ID + " = "
                        + cong_trinh.getId(), null);
    }


    public long xoa(Cong_Trinh cong_trinh) {
        return database.delete(DBHelper_CT
                .TEN_BANG_CONGTRINH, DBHelper_CT
                .MACT + " = " + "'" +
                cong_trinh.getMaCT() + "'", null);
    }

   public ArrayList<Cong_Trinh> LayDL()
    {
        ArrayList<Cong_Trinh> data = new ArrayList<>();
        String sql="select * from CongTrinh";
        SQLiteDatabase db= dbHelper_CT.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);

        try {
            cursor.moveToFirst();
            do {
                Cong_Trinh cong_trinh = new Cong_Trinh();
                cong_trinh.setMaCT(cursor.getString(0));
                cong_trinh.setTenCT(cursor.getString(1));

                data.add(cong_trinh);
            }
            while (cursor.moveToNext());
        }
        catch (Exception ex)
        {

        }


        return  data;
    }


   
}
