package tdc.edu.vn.test.CustomAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import android.widget.ImageView;
import android.widget.TextView;
import tdc.edu.vn.test.R;
import tdc.edu.vn.test.Model.VanChuyen;

public class CustomAdapter_VC extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<VanChuyen> data;

    public CustomAdapter_VC(Context context, int resource, ArrayList<VanChuyen> data) {
        super(context, resource);
        this.context=context;
        this.resource= resource;
        this.data= data;
    }
    @Override
    public int getCount() {
        return data.size();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(resource,null);
        ImageView imgPhuongTien= view.findViewById(R.id.imgPhuongTien);
        TextView tvNVC= view.findViewById(R.id.txtmact);
        TextView tvsoluong= view.findViewById(R.id.txttenct);
        TextView tvtattu= view.findViewById(R.id.txtdiachi);
        TextView tvcongtrinh= view.findViewById(R.id.tvcongtrinh);
        VanChuyen vanChuyen = data.get(position);
        if(vanChuyen.getGioiTinh())
            imgPhuongTien.setImageResource(R.drawable.container);
        else
            imgPhuongTien.setImageResource(R.drawable.xetai);
        tvNVC.setText(vanChuyen.getNgayVC());
        tvsoluong.setText(vanChuyen.getSoLuong());
        tvtattu.setText(vanChuyen.getVatTu());
        tvcongtrinh.setText(vanChuyen.getCongTrinh());

        return  view;
    }
}
