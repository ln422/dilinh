package tdc.edu.vn.myapplication.GiaoDien;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;

import java.util.ArrayList;

import tdc.edu.vn.myapplication.Adapter.CustomApdapterSV;
import tdc.edu.vn.myapplication.DataBase.DBSinhVien;
import tdc.edu.vn.myapplication.Model.SinhVien;
import tdc.edu.vn.myapplication.R;

public class MainActivityGridView extends AppCompatActivity {

    GridView gvDanhSachSV;


    CustomApdapterSV apdapter ;
    ArrayList<SinhVien> data_SV = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_gridview);
        setConTrol();
        setEvent();
    }

    private void setEvent() {

        HienThiDL();



    }

    private  void HienThiDL()
    {
        DBSinhVien dbSinhVien = new DBSinhVien(this);
        data_SV = dbSinhVien.LayDL();
        apdapter = new CustomApdapterSV(this, R.layout.listview_item,data_SV);
        gvDanhSachSV.setAdapter(apdapter);
    }



    private void setConTrol() {
        gvDanhSachSV = findViewById(R.id.gvDanhSach);


    }
}
